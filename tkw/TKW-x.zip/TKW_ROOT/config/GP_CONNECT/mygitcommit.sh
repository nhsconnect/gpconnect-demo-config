#!/bin/bash
#
# commit for GP_CONNECT tkw config
#
#DRY_RUN=--dry-run


# 24/4/20
#git commit $DRY_RUN -m "Added documents capability. Various tweaks to configs. Responses in a separate folder"

# 24/4/20
#git commit $DRY_RUN -m "Fixed a couple of paths."

# 27/4/20
#git commit $DRY_RUN -m "Added diary entry search date validaiton and hapifhir validation of xml input."

# 28/4/20
#git commit $DRY_RUN -m "Added added search documents created date validation."

# 28/4/29
#git commit $DRY_RUN -m "Added rules expression of type Class allowing java extensions for comparing fhir dates extracted from text sources via reg exps."

# 4/5/20
#git commit $DRY_RUN -m "ADjusted alignment of comment on regexp."

# 15/5/20
#git commit $DRY_RUN -m "Added refinements to Documents."

# 18/5/20
#git commit $DRY_RUN -m "Added Ssp-To check."

# 20/5/20
#git commit $DRY_RUN -m "Handle url encoding on document reference search."

# 28/5/20
#git commit $DRY_RUN -m "Improvements to Spp-to checking."

# 29/5/20
#git commit $DRY_RUN -m "Fix for document capability statement. Mods for external config pickup in docker."

# 2/6/20
#git commit $DRY_RUN -m "Mods for document capability statement. Removed patient read, amended some search parameter types."

# 3/6/20
#git commit $DRY_RUN -m "Mods to expect plus signs to be url encoded in document search requests."

# 3/6/20
#git commit $DRY_RUN -m "Preferably with the correct value ...."

# 5/6/20
#git commit $DRY_RUN -m "Checks adjusted for URL encoding, experimental mods for default external values, check for bad parameters on doc search."

# 5/6/20
#git commit $DRY_RUN -m "Picks up inetrnal default config values in the absence of an exetrnal volume."

# 5/6/20
#git commit $DRY_RUN -m "Reports bad document search parameter more accurately."

# 10/6/20
#git commit $DRY_RUN -m "Document search no records found implemented."

# 10/6/20
#git commit $DRY_RUN -m "Inserted some rich data into patient 2 on specific medication search dates."

# 11/6/20
#git commit $DRY_RUN -m "Mods to diary entries to adjust returned resources."

# 11/6/20
#git commit $DRY_RUN -m "Mods to diary entries for patient 3 (no problems) and 4 (no entries) responses."

# 11/6/20
#git commit $DRY_RUN -m "Mods to problem retuned for patient 2 diary entries."

# 22/6/20
#git commit $DRY_RUN -m "Fix unexpected 404 error."

# 23/6/20
#git commit $DRY_RUN -m "Move to TKW_ROOT."

# 24/6/20
#git commit $DRY_RUN -m "Changes from Matts update." \
#	-m "Addresses issues #1"

# 26/6/20
#git commit $DRY_RUN -m "Added a switch for 1.2/1.5."

# 30/6/20
#git commit $DRY_RUN -m "Mods for diary entries search date checks."

# 1/7/20
#git commit $DRY_RUN -m "Added baked in 600s jwt leeway." 

# 13/7/20
#git commit $DRY_RUN -m "Backed out an invalid JWT check." \
#	-m "Addresses issue: #2"

# 14/7/20
#git commit $DRY_RUN -m "Removed all uses of the generic operation outrcome." \
#	-m "Addresses issue: #3"

# 17/7/20
#git commit $DRY_RUN -m "Moved some tkw props files to legacy_files."

# 20/7/20
#git commit $DRY_RUN -m "New opentest certs, refactored simulator.sh."

# 21/7/20
#git commit $DRY_RUN -m "General tidy up, some changes to cmd files although no longer needed."

# 28/7/20
git commit $DRY_RUN -m "Inhibit validation."

# if it all goes wrong
#git reset --soft HEAD^
