Test fhir messaging using a curl script in gp connect tstp
/mnt/encrypted/home/simonfarrow/Desktop/TKW5.0Dev/contrib/TKWAutotestManager/tstp/WebServices/host/GP_CONNECT/test_curl_messaging.sh

For ackers need to run up a resthttpserver on 4849
